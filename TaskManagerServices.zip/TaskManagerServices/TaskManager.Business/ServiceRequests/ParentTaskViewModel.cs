﻿namespace TaskManager.Business.ServiceRequests
{
    public class ParentTaskViewModel
    {
        public int ParentTaskId { get; set; }
        public string ParentTaskName { get; set; }
    }
}
