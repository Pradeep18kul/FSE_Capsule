﻿using NBench;
using System;

namespace TaskManager.Business.Tests
{
    public class TaskBusinessTests
    {
    
    }
}
